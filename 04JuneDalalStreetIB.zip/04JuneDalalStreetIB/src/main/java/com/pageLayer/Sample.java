package com.pageLayer;

public class Sample {

	public static void main(String[] args) {

		String a = "James";
		int b = 10;
		System.out.println("Harry "+a + "and" + b+ " Potter");

	}

}
